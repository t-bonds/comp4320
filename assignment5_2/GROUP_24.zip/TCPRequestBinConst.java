public interface TCPRequestBinConst {
    public static final String DEFAULT_ENCODING = "ISO-8859-1";
    public static final int SINGLE_FLAG = 1 << 0; // Least significant bit
    public static final int GROUP_NUMBER = 24;
    public static final int MAX_WIRE_LENGTH  = 1024; // Max length on the" wire"
}
